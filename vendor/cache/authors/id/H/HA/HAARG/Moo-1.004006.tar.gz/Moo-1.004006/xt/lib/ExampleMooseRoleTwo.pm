package ExampleMooseRoleTwo;
use Moose::Role;

1;

