package Foo;
$Foo::VERSION = '0.2';
1;
